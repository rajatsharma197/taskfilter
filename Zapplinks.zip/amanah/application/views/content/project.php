<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?php if($data->num_rows()): ?>

<h3 class="text-center project-heading">
<?php echo $data->row()->project_name; ?>
</h3>

<div class="content-wrap"><?php echo $data->row()->project_page; ?></div>

<?php endif; ?>

<div class="space"></div>