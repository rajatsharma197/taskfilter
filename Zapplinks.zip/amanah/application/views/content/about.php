<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<h3 class="text-center app-color"><?php echo $data->title; ?></h3>
<div class="content-wrap"><?php echo $data->description; ?></div>

<div class="space"></div>