<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?= APPMAIL; ?></title>
</head>
<body>
	<p>Hello,</p>
	<p>New contact email recieved below is the details of person.</p>
	<table style="text-align: left;">
		<tr>
			<th style="margin-right: 15px;">Name</th>
			<td><?= $data['fname']; ?></td>
		</tr>
		<tr>
			<th style="margin-right: 15px;">Email</th>
			<td><?= $data['email']; ?></td>
		</tr>
		<tr>
			<th style="margin-right: 15px;">Phone</th>
			<td><?= $data['phone']; ?></td>
		</tr>
		<tr>
			<th style="margin-right: 15px;">Message</th>
			<td><?= $data['message']; ?></td>
		</tr>
	</table>
	<p>Regards,</p>
	<p><?= APPNAME; ?></p>
</body>
</html>