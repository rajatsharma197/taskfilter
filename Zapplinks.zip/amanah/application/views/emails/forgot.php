<!DOCTYPE html>
<html>
<head>
	<title>Amanah</title>
</head>
<body>
	Hello, <?= $name ?><br>
	<p>Below is your new password for account :-</p>
	<h3><?= $pass; ?></h3>
</body>
</html>