<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?= APPNAME; ?></title>
</head>
<body>
	<p>Hello, </p>
	<p>New orphan or family sponsorship email recieved below is the details of person.</p>
	<table style="text-align: left;">
		<tr>
			<th>Name</th>
			<td><?= $data['fname']; ?></td>
		</tr>
		<tr>
			<th>Email</th>
			<td><?= $data['email']; ?></td>
		</tr>
		<tr>
			<th>Phone</th>
			<td><?= $data['phone']; ?></td>
		</tr>
		<tr>
			<th>Sponsor Date</th>
			<td><?= $data['sponsor_date']; ?></td>
		</tr>
		<tr>
			<th>Message</th>
			<td><?= $data['message']; ?></td>
		</tr>
	</table>
	<p>Regards,</p>
	<p><?= APPNAME; ?></p>
</body>
</html>