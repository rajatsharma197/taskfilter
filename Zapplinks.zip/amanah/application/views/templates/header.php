<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Al-Amanha</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,700" rel="stylesheet">
	<style type="text/css">
		body{font-family: 'Nunito', sans-serif;font-size: 15px;}
		img{max-width: 100%;height: auto;}
		.project-heading{color: #000000;margin-bottom: 15px;}
		.space{margin-top: 30px;}
		.app-color{color: #dd961f;}
	</style>
</head>
<body>

<div class="container">