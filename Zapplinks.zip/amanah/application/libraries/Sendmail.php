<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//User mail send library
class Sendmail {

	private $CI;
	private $subject;
	private $from;
	private $from_name;

	public function __construct()
	{
		//Get instance of ci
		$this->CI = & get_instance();

		$this->CI->load->library('email');

		$this->from = 'info@infograins.com';
		$this->name = APPNAME;
	}

	//Send user forgot pass mail
	public function forgot($email, $pass, $name)
	{
		//Set body with data
		$body = $this->CI->load->view(
								'emails/forgot',
								[
									'pass' => $pass,
									'name' => $name
								],
								true
							);
		//Set email subject
		$this->subject = APPNAME.' - New password request !';
		//Send verification mail
		return $this->_send_email($email, $body);
	}

	//Function to send contact mail
	public function contact($data)
	{
		//Set body with data
		$body = $this->CI->load->view(
								'emails/contact',
								['data' => $data],
								true
							);

		//Set email subject
		$this->subject = APPNAME.' - New contact query !';

		//Send contact mail
		return $this->_send_email(APPMAIL, $body);
	}

	//Function to send sponsor email
	public function sponsor($data)
	{
		//Set body with data
		$body = $this->CI->load->view(
								'emails/sponsor',
								['data' => $data],
								true
							);

		//Set email subject
		$this->subject = APPNAME.' - Orphan or family sponsorship mail !';

		//Send contact mail
		return $this->_send_email(APPMAIL, $body);
	}

	//Function to send email
	private function _send_email($email, $body)
	{
		//Email config
		$config['charset']  = 'iso-8859-1';
		$config['mailtype'] = 'html';

		//Initialize email with config
		$this->CI->email->initialize($config);

		//Set from email and name
		$this->CI->email->from($this->from, $this->name);

		//Set to email
		$this->CI->email->to($email);
		
		//Set subject
		$this->CI->email->subject($this->subject);

		//Set email body
		$this->CI->email->message($body);

		return $this->CI->email->send();
	}
}
