<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Event model for event DB Operations
class Event_model extends MY_Model
{
	//@var for table
	private $table;

	public function __construct()
	{
		parent::__construct();
		//Set table name
		$this->table = 'am_events';
	}

	//Function to get Events
	public function get($event_ID = null)
	{
		//If id is not setted return all
		if( is_null($event_ID) )
		{
			return $this->db
						->select([
							'event_ID', 'event_name', 'event_description',
							'event_picture', 'event_date_time', 'event_venue', 
							'event_slider'
						])
						->get($this->table);
		}

		return $this->db
					->select([
						'event_ID', 'event_name', 'event_description',
						'event_picture', 'event_date_time', 'event_venue', 
						'event_slider'
					])
					->where('event_ID', $event_ID)
					->limit(1)
					->get($this->table);
	}
}