<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Option model for option DB Operations
class Option_model extends MY_Model
{
	//@var for table
	private $table;

	public function __construct()
	{
		parent::__construct();
		//Set table name
		$this->table = 'am_options';
	}

	//Function to get Events
	public function get($option = '')
	{
		return $this->db
					->where('option_name', $option)
					->limit(1)
					->select('option_value')
					->get($this->table);
	}
}