<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Team model for team DB Operations
class Team_model extends MY_Model
{
	//@var for table
	private $table;

	public function __construct()
	{
		parent::__construct();
		//Set table name
		$this->table = 'am_team';
	}

	//Function to get team members
	public function get($member_ID = null)
	{
		//If id is not setted return all
		if( is_null($member_ID) )
		{
			return $this->db
						->select([
							'member_ID', 'member_name',
							'member_position', 'member_photo'
						])
						->get($this->table);
		}

		return $this->db
					->select([
						'member_ID', 'member_name',
						'member_position', 'member_photo'
					])
					->where('member_ID', $member_ID)
					->limit(1)
					->get($this->table);
	}
}