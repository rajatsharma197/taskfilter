<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Project model for project DB Operations
class Project_model extends MY_Model
{
	//@var for table
	private $table;

	public function __construct()
	{
		parent::__construct();
		//Set table name
		$this->table = 'am_projects';
	}

	//Function to get project
	public function get($project_ID = null)
	{
		//If id is not setted return all
		if( is_null($project_ID) )
		{
			return $this->db
						->select([
							'project_ID', 'project_name', 'project_description', 
							'project_icon'
						])
						->get($this->table);
		}

		return $this->db
					->select([
							'project_ID', 'project_name', 'project_description', 
							'project_icon', 'project_page'
						])
					->where('project_ID', $project_ID)
					->limit(1)
					->get($this->table);
	}
}