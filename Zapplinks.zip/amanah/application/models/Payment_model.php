<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Payment model for option DB Operations
class Payment_model extends MY_Model
{
	//@var for table
	private $table;

	public function __construct()
	{
		parent::__construct();
		//Set table name
		$this->table = 'am_payments';
	}

	//Function to get Payment
	public function get($userID)
	{
		return $this->db
					->where('user_ID', $userID)
					->get($this->table);
	}

	//Function to add payment
	public function add($data)
	{
		$this->db
			 ->insert($this->table, $data);

		return $this->db->insert_id();
	}
}