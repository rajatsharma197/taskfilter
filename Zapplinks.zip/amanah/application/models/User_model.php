<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//User model for user DB Operations
class User_model extends MY_Model
{
	//@var for table
	private $table;

	public function __construct()
	{
		parent::__construct();
		//Set table name
		$this->table = 'am_users';
	}

	// ---------------------------------------------------------------

	//Function to get user
	//based on user id
	public function get($userID)
	{
		return $this->db
					->select([
						'user_ID', 'full_name', 'email_address',
						'phone', 'profile_picture', 'password'
					])
					->where('user_ID', $userID)
					->limit(1)
					->get($this->table)
					->row();
	}

	// ---------------------------------------------------------------

	//Function to get user by email
	public function get_by_email($email)
	{
		return $this->db
					->select([
						'user_ID', 'full_name', 'email_address',
						'phone', 'profile_picture', 'password'
					])
					->where('email_address', $email)
					->limit(1)
					->get($this->table)
					->row();
	}

	// ---------------------------------------------------------------

	//Function to check if user exist
	//Based on user id
	public function has($id)
	{
		$q = $this->db
				  ->where('user_ID', $id)
				  ->limit(1)
				  ->get($this->table);

		if( $q->num_rows() )
			return TRUE;

		return FALSE;
	}

	// ---------------------------------------------------------------

	//Function to check user
	//for user login purpose
	public function check($email, $pass)
	{
		$q = $this->db
				  ->where('email_address', $email)
				  ->limit(1)
				  ->get($this->table);

		//If no user found
		if( $q->num_rows() == 0 )
			return FALSE;

		//If password matched
		if( password_verify($pass, $q->row()->password) )
			return $q->row()->user_ID;

		return FALSE;
	}

	// ---------------------------------------------------------------

	//Function to add user
	public function add($data)
	{
		$this->db
			 ->insert($this->table, $data);

		return $this->db->insert_id();
	}

	// ---------------------------------------------------------------

	//Function to update user
	public function update($userID, $data)
	{
		$this->db
			 ->where('user_ID', $userID)
			 ->update($this->table, $data);

		return $this->db->affected_rows();
	}

	// ---------------------------------------------------------------

	//Check if email exist
	public function has_email($email)
	{
		$q = $this->db
				  ->where('email_address', $email)
				  ->limit(1)
				  ->get($this->table);

		if( $q->num_rows() )
			return TRUE;

		return FALSE;
	}

	// ---------------------------------------------------------------

	//Check if phone number exist
	//Check for both sign up and profile update
	public function has_phone($phone, $user = null)
	{
		if( is_null($user) )
		{
			$q = $this->db
					  ->where('phone', $phone)
					  ->limit(1)
					  ->get($this->table);
		}
		else
		{
			$q = $this->db
					  ->where([
					  		'phone' => $phone, 
					  		'user_ID !=' => $user
					  	])
					  ->limit(1)
					  ->get($this->table);
		}

		if( $q->num_rows() )
			return TRUE;

		return FALSE;
	}

	// ---------------------------------------------------------------
}
