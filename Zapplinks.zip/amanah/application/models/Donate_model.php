<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Donate model for donate DB Operations
class Donate_model extends MY_Model
{
	//@var for table
	private $table;

	public function __construct()
	{
		parent::__construct();
		//Set table name
		$this->table = 'am_dontes';
	}

	//Function to get Donate packs
	public function get($donate_ID = null)
	{
		//If id is not setted return all
		if( is_null($donate_ID) )
		{
			return $this->db
						->select([
							'donate_ID', 'donate_title', 'donate_subtitle', 
							'donate_amount', 'donate_points', 'donate_link'
						])
						->get($this->table);
		}

		return $this->db
					->select([
						'donate_ID', 'donate_title', 'donate_subtitle', 
						'donate_amount', 'donate_points', 'donate_link'
					])
					->where('donate_ID', $donate_ID)
					->limit(1)
					->get($this->table);
	}
}