<?php
defined('BASEPATH') OR exit('No direct script access allowed');

# Include REST API Library
require APPPATH . 'libraries/REST_Controller.php';

/**
 * MY controller for extends all Controllers
 */
class MY_Controller extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	//Function load view with header footer
	protected function loadView($view = '', $data = '')
	{
		if( empty($view) ) return;

		//Load view with header footer
		$this->load->view('templates/header');
		$this->load->view($view, $data);
		$this->load->view('templates/footer');
	}
}

// ------------------------------------------------------------

/**
 * Api controller for all APIs Controller
 */
class API_Controller extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	//Function to generate token
	protected function _token()
	{
		return md5(uniqid(microtime()));
	}

	//Function to protect pass sha1
	protected function _passProtect($pass)
	{
		return password_hash($pass, PASSWORD_DEFAULT);
	}
}