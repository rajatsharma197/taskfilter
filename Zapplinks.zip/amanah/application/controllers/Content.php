<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Donate api controller
class Content extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		//Load option model
		$this->load->model("option_model", "option");
		$this->load->model("project_model", "project");
		$this->load->helper("html");
	}

	// ---------------------------------------------------------------

	//Function to get donates all or single based on id
	public function about()
	{
		$pageinfo = $this->option->get("about_page");

		if( $pageinfo->num_rows() )
		{
			//page info data decode json
			$data = json_decode($pageinfo->row()->option_value);
			$this->loadView('content/about', ["data" => $data]);
		}
	}

	// ---------------------------------------------------------------

	//Function for project web views
	//@Param project id
	public function project($id = '')
	{
		//Return if empty id
		if( empty($id) ) return;

		$data = $this->project->get($id);

		$this->loadView('content/project', ["data" => $data]);
	}

	// ---------------------------------------------------------------

	//Function to reset fogot password
	//@Param unique user token
	public function reset_ac_password($token)
	{
		//Load user model
		$this->load->model('user_model', 'user');

		//Check for token validation
		if( empty($token) )
			return;

		//Check for token to be exist
		if( ! $this->user->has_token($token) )
			return;

		//Begin to password reset
	}
}