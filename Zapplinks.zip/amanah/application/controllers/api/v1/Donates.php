<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Donate api controller
class Donates extends API_Controller
{
	public function __construct()
	{
		parent::__construct();
		//Load donate model
		$this->load->model("donate_model", "donate");
	}

	// ---------------------------------------------------------------

	//Function to get donates all or single based on id
	public function get_get($id = '')
	{
		//Get donate data
		$donate = ( !empty($id) )
				? $this->donate->get($id)
				: $this->donate->get();

		//If donate found
		if( $donate->num_rows() )
		{
			//Loop through all result
			foreach ($donate->result() as $one)
			{
				$points = explode(',', $one->donate_points);

				//Amount
				$amount = explode(' ', $one->donate_amount);

				$output[] = [
					"donate_ID"	=> $one->donate_ID,
					"donate_title"=> $one->donate_title,
					"donate_subtitle" => $one->donate_subtitle,
					"donate_amount" => $amount[1],
					"donate_points" => $points,
					"donate_link" => $one->donate_link
				];
			}

			//Donate data
			return $this->response([
				'status'	=> "true",
				'message'	=> 'Donates Data Listed !',
				'object'	=> $output
			], REST_Controller::HTTP_OK);
		}

		//If not found any donate
		return $this->response([
			'status'	=> "false",
			'message'	=> 'No Donate Found !'
		], REST_Controller::HTTP_OK);
	}
}