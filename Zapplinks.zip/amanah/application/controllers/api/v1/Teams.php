<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Donate api controller
class Teams extends API_Controller
{
	public function __construct()
	{
		parent::__construct();
		//Load donate model
		$this->load->model("team_model", "team");
	}

	// ---------------------------------------------------------------

	//Function to get donates all or single based on id
	public function get_get($id = '')
	{
		//Get donate data
		$team = ( !empty($id) )
				? $this->team->get($id)
				: $this->team->get();

		//If donate found
		if( $team->num_rows() )
		{
			//Loop through all result
			foreach ($team->result() as $one)
			{
				$output[] = $one;
			}

			//Donate data
			return $this->response([
				'status'	=> "true",
				'message'	=> 'Team Data Listed !',
				'object'	=> $output
			], REST_Controller::HTTP_OK);
		}

		//If not found any donate
		return $this->response([
			'status'	=> "false",
			'message'	=> 'No Team Found !'
		], REST_Controller::HTTP_OK);
	}
}