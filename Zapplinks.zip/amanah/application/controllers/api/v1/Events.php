<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Event api controller
class Events extends API_Controller
{
	public function __construct()
	{
		parent::__construct();
		//Load event model
		$this->load->model("event_model", "event");
	}

	// ---------------------------------------------------------------

	//Function to get event all or single based on id
	public function get_get($id = '')
	{
		//Get event data
		$event = ( !empty($id) )
				? $this->event->get($id)
				: $this->event->get();

		//If event found
		if( $event->num_rows() )
		{
			//Loop through all result
			foreach ($event->result() as $one)
			{
				$output[] = [
					"event_ID" => $one->event_ID,
				    "event_name" => $one->event_name,
				    "event_description" => $one->event_description,
				    "event_picture" => $one->event_picture,
				    "event_date_time" => $one->event_date_time,
				    "event_venue" => $one->event_venue,
				    "event_slider" => explode(',', $one->event_slider)
				];
			}

			//Event data
			return $this->response([
				'status'	=> "true",
				'message'	=> 'Events Data Listed !',
				'object'	=> $output
			], REST_Controller::HTTP_OK);
		}

		//If not found any event
		return $this->response([
			'status'	=> "false",
			'message'	=> 'No Event Found !'
		], REST_Controller::HTTP_OK);
	}
}