<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//User api controller
class User extends API_Controller
{
	public function __construct()
	{
		parent::__construct();
		//Load user model
		$this->load->model("user_model", "user");
	}

	// ---------------------------------------------------------------

	//Function to get user details
	//Based on user id
	public function get_post()
	{
		//Get user id
		$id = $this->input->post('user_id');

		//Check for valid user id
		if( empty($id) )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "user is not valid",
			], REST_Controller::HTTP_OK);
		}

		//Check if user exist
		$this->_has_user($id);

		//Get user profile data
		$userData = $this->user->get($id);

		//Profile picture
		$profile = (empty($userData->profile_picture) OR 
					!file_exists(PROFILEPATH . $userData->profile_picture))
					? base_url("uploads/user_profile/avatar.png")
					: base_url("uploads/user_profile/{$userData->profile_picture}");

		//Return response
		return $this->response([
			'status'	=> "true",
			'message'	=> "Profile listed successfully.",
			'object'	=> array(
				'user_ID' => $userData->user_ID,
				'full_name' => $userData->full_name,
				'email_address' => $userData->email_address,
				'phone' => $userData->phone,
				'profile_picture' => $profile,
			)
		], REST_Controller::HTTP_OK);
	}

	// ---------------------------------------------------------------

	//Function to signup user
	//Get data params
	public function signup_post()
	{
		//Check for validation errors
		if( $this->form_validation->run('user_signup') === FALSE )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "validation errors",
				'errors'	=> $this->form_validation->error_array(),
			], REST_Controller::HTTP_OK);
		}

		//Get email and phone
		$email = $this->input->post('email');
		$phone = $this->input->post('phone');

		//Check if email already exist
		if( $this->user->has_email($email) )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "email address already exist",
			], REST_Controller::HTTP_OK);
		}

		//Check if phone already exist
		if( $this->user->has_phone($phone) )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "phone number already exist",
			], REST_Controller::HTTP_OK);
		}

		//Begin to signup
		$user = $this->user->add([
			'full_name' => $this->input->post('full_name'),
			'email_address' => $email,
			'password' => $this->_passProtect($this->input->post('password')),
			'phone' => $phone,
			'token' => $this->_token(),
			'created_at' => theDate(),
			'updated_at' => theDate(),
			'created_ip' => theIp(),
		]);

		//Check if user created or not
		if( ! $user )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "Unable to register try again",
			], REST_Controller::HTTP_OK);
		}

		//Get user profile data
		$userData = $this->user->get($user);

		//Profile picture
		$profile = (empty($userData->profile_picture) OR 
					!file_exists(PROFILEPATH . $userData->profile_picture))
					? base_url("uploads/user_profile/avatar.png")
					: base_url("uploads/user_profile/{$userData->profile_picture}");

		//Return response
		return $this->response([
			'status'	=> "true",
			'message'	=> "Registered successfully.",
			'object'	=> array(
				'user_ID' => $userData->user_ID,
				'full_name' => $userData->full_name,
				'email_address' => $userData->email_address,
				'phone' => $userData->phone,
				'profile_picture' => $profile,
			)
		], REST_Controller::HTTP_OK);
	}


	// ---------------------------------------------------------------

	//Function to signin user
	//Get login params
	public function signin_post()
	{
		//Check for validation errors
		if( $this->form_validation->run('user_signin') === FALSE )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "validation errors",
				'errors'	=> $this->form_validation->error_array(),
			], REST_Controller::HTTP_OK);
		}
		
		//check for email and password match
		$user = $this->user->check(
			$this->input->post('email'),
			$this->input->post('password')
		);

		//If user not found
		if( $user == FALSE )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "Invalid login credentials",
			], REST_Controller::HTTP_OK);
		}

		//Get user profile data
		$userData = $this->user->get($user);

		//Profile picture
		$profile = (empty($userData->profile_picture) OR 
					!file_exists(PROFILEPATH . $userData->profile_picture))
					? base_url("uploads/user_profile/avatar.png")
					: base_url("uploads/user_profile/{$userData->profile_picture}");

		//Return response
		return $this->response([
			'status'	=> "true",
			'message'	=> "Login successful.",
			'object'	=> array(
				'user_ID' => $userData->user_ID,
				'full_name' => $userData->full_name,
				'email_address' => $userData->email_address,
				'phone' => $userData->phone,
				'profile_picture' => $profile,
			)
		], REST_Controller::HTTP_OK);
	}

	// ---------------------------------------------------------------

	//Function to update user profile
	public function update_post()
	{
		//Check for validation
		if( $this->form_validation->run('user_update') === FALSE )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "validation errors",
				'errors'	=> $this->form_validation->error_array(),
			], REST_Controller::HTTP_OK);
		}

		//Get user id
		$userID = $this->input->post('user_id');

		//Check if user exist
		$this->_has_user($userID);

		//Get phone
		$phone = $this->input->post('phone');

		//Check if phone already exist
		if( $this->user->has_phone($phone, $userID) )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "phone number already exist",
			], REST_Controller::HTTP_OK);
		}

		//Update user profile
		$this->user->update($userID, [
			'full_name' => $this->input->post('full_name'),
			'phone' => $phone,
		]);

		//Check if profile images is setted
		if( isset($_FILES['user_dp']['name']) )
		{
			// Upload configs
			$config['upload_path']		= PROFILEPATH;
	        $config['allowed_types']	= 'gif|jpg|png|jpeg';
	        $config['file_name']		= md5(uniqid());

	        // upload library
	        $this->load->library('upload', $config);

	        // If profile not uploaded
	        if ( ! $this->upload->do_upload('user_dp'))
	        {
				// Return the response
				return $this->response(array(
					'status' 	=> "false",
					'message'  	=> $this->upload->display_errors('', '')
				), REST_Controller::HTTP_OK);
	        }
	        
	    	//Update user profile picture
			$this->user->update($userID, [
				'profile_picture' => $this->upload->data('file_name'),
			]);
		}

		//Get user profile data
		$userData = $this->user->get($userID);

		//Profile picture
		$profile = (empty($userData->profile_picture) OR 
					!file_exists(PROFILEPATH . $userData->profile_picture))
					? base_url("uploads/user_profile/avatar.png")
					: base_url("uploads/user_profile/{$userData->profile_picture}");

		//Return response
		return $this->response([
			'status'	=> "true",
			'message'	=> "Profile updated successfully.",
			'object'	=> array(
				'user_ID' => $userData->user_ID,
				'full_name' => $userData->full_name,
				'email_address' => $userData->email_address,
				'phone' => $userData->phone,
				'profile_picture' => $profile,
			)
		], REST_Controller::HTTP_OK);
	}

	// ---------------------------------------------------------------

	//Function to change password
	public function changePass_post()
	{
		//Check for validation
		if( $this->form_validation->run('user_changepass') === FALSE )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "validation errors",
				'errors'	=> $this->form_validation->error_array(),
			], REST_Controller::HTTP_OK);
		}

		//Get user id
		$userID = $this->input->post('user_id');

		//Check if user exist
		$this->_has_user($userID);

		//Get user profile data
		$userData = $this->user->get($userID);

		//Currrent pass
		$curPass = $this->input->post('current_pass');
		$newPass = $this->input->post('password');

		//Check if new and current password is same
		if( $curPass == $newPass )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "New password can not be same as current password.",
			], REST_Controller::HTTP_OK);
		}

		//Check for current password match
		if( ! password_verify($curPass, $userData->password)  )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "Current password not match.",
			], REST_Controller::HTTP_OK);
		}

		//Update user password
		$this->user->update($userID, [
			'password' => $this->_passProtect($newPass),
		]);

		//Return response
		return $this->response([
			'status'	=> "true",
			'message'	=> "Password updated successfully.",
		], REST_Controller::HTTP_OK);
	}

	// ---------------------------------------------------------------

	public function forgot_post()
	{

		//Get email and phone
		$email = $this->input->post('email');

		//Check for valid email address
		if( empty($email) OR ! filter_var($email, FILTER_VALIDATE_EMAIL) )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "please enter valid email",
			], REST_Controller::HTTP_OK);
		}

		//Check if email is registered or not
		if( ! $this->user->has_email($email) )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "email address not registered",
			], REST_Controller::HTTP_OK);
		}

		//make new password for user
		$newPass = "AM_".mt_rand(11111, 99999);

		//Get user data
		$userData = $this->user->get_by_email($email);

		$this->load->library('sendmail');

		$isSent = $this->sendmail->forgot($email, $newPass, $userData->full_name);

		if( $isSent )
		{
			//Update user password
			$this->user->update($userData->user_ID, [
				'password' => $this->_passProtect($newPass),
			]);

			//Return response
			return $this->response([
				'status'	=> "true",
				'message'	=> "New password has been sent to your email",
			], REST_Controller::HTTP_OK);
		}
		else
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "Unable to send new password to email",
			], REST_Controller::HTTP_OK);
		}
	}

	// ---------------------------------------------------------------

	//Function to check if user exist of not 
	private function _has_user($id)
	{
		$has = $this->user->has($id);

		//If not user exist
		if( ! $has )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "User does not exist",
			], REST_Controller::HTTP_OK);
		}
	}

	// ---------------------------------------------------------------
}
