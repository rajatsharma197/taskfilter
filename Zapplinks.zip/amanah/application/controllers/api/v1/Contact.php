<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Contact api controller
class Contact extends API_Controller
{
	//@var for subject
	private $subject;

	//Constructor function
	public function __construct()
	{
		parent::__construct();

		//Set subject
		$this->subject = 'Amanha - new contact query !';

		//Load email library
		$this->load->library('sendmail');
	}

	// ---------------------------------------------------------------

	//Function to get donates all or single based on id
	public function submit_post()
	{
		//Check for validation errors
		if( $this->form_validation->run('user_contact') === FALSE )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "validation errors",
				'errors'	=> $this->form_validation->error_array(),
			], REST_Controller::HTTP_OK);
		}

		//Check if sent
		$is_sent = $this->sendmail->contact($this->post());

		if( $is_sent )
		{
			//Return response
			return $this->response([
				'status'	=> "true",
				'message'	=> 'Message sent successfully !'
			], REST_Controller::HTTP_OK);
		}

		//Return response
		return $this->response([
			'status'	=> "false",
			'message'	=> 'Unable to send message !'
		], REST_Controller::HTTP_OK);
	}

	//Function to submit sponser email
	public function sponsor_post()
	{
		//Check for validation errors
		if( $this->form_validation->run('user_sponsor') === FALSE )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "validation errors",
				'errors'	=> $this->form_validation->error_array(),
			], REST_Controller::HTTP_OK);
		}

		//Check if sent
		$is_sent = $this->sendmail->sponsor($this->post());

		if( $is_sent )
		{
			//Return response
			return $this->response([
				'status'	=> "true",
				'message'	=> 'Message sent successfully !'
			], REST_Controller::HTTP_OK);
		}

		//Return response
		return $this->response([
			'status'	=> "false",
			'message'	=> 'Unable to send message !'
		], REST_Controller::HTTP_OK);
	}
}