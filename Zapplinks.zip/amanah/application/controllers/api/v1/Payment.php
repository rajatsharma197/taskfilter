<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Donate api controller
class Payment extends API_Controller
{
	public function __construct()
	{
		parent::__construct();
		//Load donate model
		$this->load->model("payment_model", "payment");
		$this->load->model("user_model", "user");
	}

	// ---------------------------------------------------------------

	//Function to get user payments
	public function get_post()
	{
		$userID = $this->input->post('user_id');

		if( empty($userID) )
		{
			//Event data
			return $this->response([
				'status'	=> "false",
				'message'	=> 'user is not valid !'
			], REST_Controller::HTTP_OK);
		}

		//Check for user exist or not
		$this->_has_user($userID);

		//Get event data
		$payment = $this->payment->get($userID);

		//If event found
		if( $payment->num_rows() )
		{
			//Loop through all result
			foreach ($payment->result() as $one)
			{
				$output[] = [
					"user_ID" => $one->user_ID,
				    "donate_ID" => $one->donate_ID,
				    "donate_name" => $this->_getDonateFor($one->donate_ID),
				    "amount" => $one->amount,
				    "transaction_id" => $one->transaction_id,
				    "payment_time" => $one->created_at,
				];
			}

			//Payment data
			return $this->response([
				'status'	=> "true",
				'message'	=> 'Payment History Listed !',
				'object'	=> $output
			], REST_Controller::HTTP_OK);
		}

		//If not found any payment
		return $this->response([
			'status'	=> "false",
			'message'	=> 'No Payment History Found !'
		], REST_Controller::HTTP_OK);
	}

	// ---------------------------------------------------------------

	//Function to make user payment
	public function make_post()
	{
		if( $this->form_validation->run('add_payment') === FALSE )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "validation errors",
				'errors'	=> $this->form_validation->error_array(),
			], REST_Controller::HTTP_OK);
		}

		$userID = $this->input->post('user_id');

		//Not guest user
		if($userID != 0 )
		{
			//Check for user exist or not
			$this->_has_user($userID);
		}

		$this->payment->add([
			'user_ID' => $this->input->post('user_id'),
			'donate_ID' => $this->input->post('donate_id'),
			'amount' => $this->input->post('amount'),
			'transaction_id' => $this->input->post('transaction_id'),
			'created_at' => theDate(),
			'created_ip' => theIp(),
		]);

		//Return response
		return $this->response([
			'status'	=> "true",
			'message'	=> "Payment added successfully.",
		], REST_Controller::HTTP_OK);
	}


	// ---------------------------------------------------------------

	//Function to check if user exist of not 
	private function _has_user($id)
	{
		$has = $this->user->has($id);

		//If not user exist
		if( ! $has )
		{
			//Return response
			return $this->response([
				'status'	=> "false",
				'message'	=> "User does not exist",
			], REST_Controller::HTTP_OK);
		}
	}

	//Function to get donate name
	private function _getDonateFor($id)
	{
		$this->load->model('donate_model', 'donate');

		$data = $this->donate->get($id);

		if( $data->num_rows() )
			return $data->row()->donate_title;

		return 'N.A.';
	}
}