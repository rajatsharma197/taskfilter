<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Donate api controller
class Projects extends API_Controller
{
	public function __construct()
	{
		parent::__construct();
		//Load donate model
		$this->load->model("project_model", "project");
	}

	// ---------------------------------------------------------------

	//Function to get donates all or single based on id
	public function get_get($id = '')
	{
		//Get donate data
		$project = ( !empty($id) )
				? $this->project->get($id)
				: $this->project->get();

		//If donate found
		if( $project->num_rows() )
		{
			//Loop through all result
			foreach ($project->result() as $one)
			{
				$output[] = $one;
			}

			//Donate data
			return $this->response([
				'status'	=> "true",
				'message'	=> 'Projects Data Listed !',
				'object'	=> $output
			], REST_Controller::HTTP_OK);
		}

		//If not found any donate
		return $this->response([
			'status'	=> "false",
			'message'	=> 'No Project Found !'
		], REST_Controller::HTTP_OK);
	}
}