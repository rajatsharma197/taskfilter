<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Function for options api
class Options extends API_Controller
{
	public function __construct()
	{
		parent::__construct();
		//Load option model
		$this->load->model("option_model", "option");
	}

	//Function get bankinfo
	public function bankinfo_get()
	{
		$bankinfo = $this->option->get('bank_info');

		if( $bankinfo->num_rows() )
		{
			//Bank info data decode json
			$data = json_decode($bankinfo->row()->option_value);
			
			//Bank info reponse
			return $this->response([
				'status'	=> "true",
				'message'	=> 'Bank Info Listed !',
				"object"	=> $data
			], REST_Controller::HTTP_OK);
		}

		return $this->response([
			'status'	=> "false",
			'message'	=> 'Bank Info Not Found !'
		], REST_Controller::HTTP_OK);
	}

	//Function get countdown date
	public function countdown_get()
	{
		$countdown = $this->option->get('counter_time');

		if( $countdown->num_rows() )
		{
			//coundown info reponse
			return $this->response([
				'status'	=> "true",
				'message'	=> 'Countdown Time Listed !',
				'object'	=> array(
					'countdown_time'	=> $countdown->row()->option_value,
				)
			], REST_Controller::HTTP_OK);
		}

		return $this->response([
			'status'	=> "false",
			'message'	=> 'Countdown Time Not Found !'
		], REST_Controller::HTTP_OK);
	}

	//Function to get page info
	public function page_get()
	{
		//Get page name
		$page_name = $this->get('page_name');

		if( empty($page_name) )
		{
			return $this->response([
				'status'	=> "false",
				'message'	=> 'Please check page name !'
			], REST_Controller::HTTP_OK);
		}

		$pageinfo = $this->option->get("{$page_name}_page");

		if( $pageinfo->num_rows() )
		{
			//page info data decode json
			$data = json_decode($pageinfo->row()->option_value);

			//If page is event then add sub description
			$output = ($page_name == 'event')
						? array(
							'title'			=> $data->title,
							'description'	=> $data->description,
							'sub_description'	=> $data->sub_description
						)
						: array(
							'title'			=> $data->title,
							'description'	=> $data->description
						);
			
			//page info reponse
			return $this->response([
				'status'		=> "true",
				'message'		=> 'Page Content Listed !',
				'object'		=> $output
			], REST_Controller::HTTP_OK);
		}

		return $this->response([
			'status'	=> "false",
			'message'	=> 'Page Content Not Found !'
		], REST_Controller::HTTP_OK);
	}

	//Function get slider images
	public function slider_get()
	{
		$slider = $this->option->get('slider_images');

		if( $slider->num_rows() )
		{
			$sliderImg = explode(',', $slider->row()->option_value);

			foreach ($sliderImg as $one)
			{
				$output[] = array("image" => $one);
			}

			//coundown info reponse
			return $this->response([
				'status'	=> "true",
				'message'	=> 'Slider Images Listed !',
				'object'		=> $output,
			], REST_Controller::HTTP_OK);
		}

		return $this->response([
			'status'	=> "false",
			'message'	=> 'Slider Image Not Found !'
		], REST_Controller::HTTP_OK);
	}

	//Function to get office address
	public function address_get()
	{
		$office = $this->option->get("offices");

		if( $office->num_rows() )
		{
			//office address reponse
			return $this->response([
				'status'		=> "true",
				'message'		=> 'Office Address Listed !',
				'object'			=> json_decode($office->row()->option_value)
			], REST_Controller::HTTP_OK);
		}

		return $this->response([
			'status'	=> "false",
			'message'	=> 'Office Address Not Found !'
		], REST_Controller::HTTP_OK);
	}
}