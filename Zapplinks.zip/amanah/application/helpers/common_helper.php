<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if( ! function_exists('theDate') )
{
	// Function return date in correct formate for db
	function theDate()
	{
		return date('Y-m-d H:i:s');
	}
}

if( ! function_exists('theIp') )
{
	// Function return ip address
	function theIp()
	{
		$CI = & get_instance();
		return $CI->input->ip_address();
	}
}