<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config = array(

	//User register validation
	'user_signup' => array(

		array(
			'field' => 'full_name',
			'label' => 'Full name',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter your full name.'
			)
		),

		array(
			'field' => 'email',
			'label' => 'email address',
			'rules' => 'required|valid_email',
			'errors' => array(
				'required' => 'please enter your email address.',
				'valid_email' => 'please enter valid email address.'
			)
		),

		array(
			'field' => 'phone',
			'label' => 'Phone number',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter your phone number.'
			)
		),

		array(
			'field' => 'password',
			'label' => 'Password',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter your password.'
			)
		),
	),

	//User login validation
	'user_signin' => array(

		array(
			'field' => 'email',
			'label' => 'email address',
			'rules' => 'required|valid_email',
			'errors' => array(
				'required' => 'please enter your email address.',
				'valid_email' => 'please enter valid email address.',
			)
		),

		array(
			'field' => 'password',
			'label' => 'Password',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter your password.'
			)
		),
	),


	//User register validation
	'user_update' => array(

		array(
			'field' => 'user_id',
			'label' => 'User id',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please check user id.'
			)
		),

		array(
			'field' => 'full_name',
			'label' => 'Full name',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter your full name.'
			)
		),

		array(
			'field' => 'phone',
			'label' => 'Phone number',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter your phone number.',
				'is_unique' => 'phone number already exist.'
			)
		),
	),

	//Change password validation
	'user_changepass' => array(

		array(
			'field' => 'user_id',
			'label' => 'User id',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please check user id.'
			)
		),

		array(
			'field' => 'password',
			'label' => 'Password',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter your password.'
			)
		),

		array(
			'field' => 'current_pass',
			'label' => 'Currnet password',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter your current password.'
			)
		),
	),

	//Add user payment validation
	'add_payment' => array(

		array(
			'field' => 'user_id',
			'label' => 'User id',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please check user id.'
			)
		),

		array(
			'field' => 'donate_id',
			'label' => 'Donate id',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please check donate id.'
			)
		),

		array(
			'field' => 'amount',
			'label' => 'Amount',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please check amount.'
			)
		),

		array(
			'field' => 'transaction_id',
			'label' => 'Transaction id',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please check transaction id.'
			)
		),
	),


	//User contact validation
	'user_contact' => array(

		array(
			'field' => 'fname',
			'label' => 'Name',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter your name.'
			)
		),

		array(
			'field' => 'email',
			'label' => 'email address',
			'rules' => 'required|valid_email',
			'errors' => array(
				'required' => 'please enter your email address.',
				'valid_email' => 'please enter valid email address.'
			)
		),

		array(
			'field' => 'phone',
			'label' => 'Phone number',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter your phone number.'
			)
		),

		array(
			'field' => 'message',
			'label' => 'Message',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter your message.'
			)
		),
	),

	//User sponsor validation
	'user_sponsor' => array(

		array(
			'field' => 'fname',
			'label' => 'Full name',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter your full name.'
			)
		),

		array(
			'field' => 'email',
			'label' => 'email address',
			'rules' => 'required|valid_email',
			'errors' => array(
				'required' => 'please enter your email address.',
				'valid_email' => 'please enter valid email address.'
			)
		),

		array(
			'field' => 'phone',
			'label' => 'Phone number',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter your phone number.'
			)
		),

		array(
			'field' => 'sponsor_date',
			'label' => 'Sponsorship start date',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter sponsorship start date.'
			)
		),

		array(
			'field' => 'message',
			'label' => 'Message',
			'rules' => 'required',
			'errors' => array(
				'required' => 'please enter your message.'
			)
		),
	),
);
