<?php
defined('BASEPATH') OR exit('No direct script access allowed');

# Include REST API Library
require APPPATH . 'libraries/REST_Controller.php';

/**
 * Rest Api controller for all APIs
 */
class Api extends REST_Controller
{
	/**
	 * Rest Api controller for all apis
	 * 
	 * @const USER_AVATAR string
	 */
	const USER_AVATAR = 'user_avatar.png';

	/**
	 * Constructor function - Some Init process
	 * 
	 * @return void OR string
	 */
	public function __construct()
	{
		# Call to parent constructor
		parent::__construct();

		# Get user id from POST
		$user = $this->post('user_id');

		# Check if user id exist but not on hitting login api
		if( isset($user) && !empty($user) &&
			$this->uri->segment(3) != 'login' )
		{
			# Check if user exist or not
			if( ! $this->api->hasUser($user) )
			{
				# Return the response with user not exist
				return $this->response(array(
					'status' 	=> false,
					'message'  	=> 'user does not exist'
				), REST_Controller::HTTP_OK);
			}
		}
	}

	// -----------------------------------------------------------------
	
	/**
	 * login function - User login API
	 * 
	 * @return string
	 */
	public function login_post()
	{
		# Get user login data params
		$user_id		= $this->post('user_id');
		$device_id		= $this->post('device_id');
		$device_token	= $this->post('device_token');
		$user_name		= $this->post('user_name');
		$address		= $this->post('address');

		# Check for required parameters
		if( empty($user_id) )
		{
			# Return the response with invalid parameters
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# Check if device id and token not empty
		if( !empty($device_token) && !empty($device_id) )
		{
			# Check of device if exist
			$hasDevice = $this->api->hasDevice($device_token, $device_id);

			# If device not exist then
			if( $hasDevice === FALSE )
			{
				# Create device add in device table
				$this->api->addDevice(array(
					'user_id' 			=> $user_id,
					'device_token' 		=> $device_token,
					'device_id' 		=> $device_id,
					'added_ip' 			=> theIp(),
					'added_time' 		=> theDate(),
					'modify_time' 		=> theDate(),
				));
			}
			else
			{
				# If device exist in table
				# Then update user id in device and modify time
				$this->api->updateDevice(array(
					'user_id' 		=> $user_id,
					'modify_time' 	=> theDate()
				), $hasDevice);
			}
		}

		# Check for user if exist
		if( $this->api->hasUser($user_id) )
		{
			# Update user device token and device id in database
			$updateData = $this->api->updateUser($user_id, array(
				'modify_time' 	=> theDate()
			));

			# Get User Profile pic
			$profile_pic = !empty($updateData->profile_picture)
						? base_url('profiles/'.$updateData->profile_picture)
						: base_url('profiles/'.self::USER_AVATAR);

			# Return the response with user data
			return $this->response(array(
				'status' 		=> true,
				'message'  		=> 'user updated',
				'user_name'		=> $updateData->user_name,
				'image'			=> $profile_pic,
				'address'		=> $updateData->address
			), REST_Controller::HTTP_OK);
		}
		else
		{
			# If user not exist
			# Create user and add data in table
			$is_created = $this->api->addUser(array(
				'user_id' 			=> $user_id,
				'facebook_id' 		=> '',
				# If has user name else set blank
				'user_name' 		=> isset($user_name) ? $user_name : '',
				'profile_picture' 	=> '',
				# If has address else set blank
				'address' 			=> isset($address) ? $address : '',
				'added_ip' 			=> theIp(),
				'added_time' 		=> theDate(),
				'modify_time' 		=> theDate(),
			));

			# If user created
			if( $is_created )
			{
				# Return response user created with user data
				return $this->response(array(
					'status' 		=> true,
					'message'  		=> 'user created',
					# If has user name else blank
					'user_name'		=> isset($user_name) ? $user_name : '',
					# Default picture for user
					'image'			=> base_url('profiles/'.self::USER_AVATAR),
					# If has address else blank
					'address'		=> isset($address) ? $address : ''
				), REST_Controller::HTTP_OK);
			}
		}
	}

	// -----------------------------------------------------------------

	/**
	 * makeFbFriends function - Friends Sync From Facebook API
	 * 
	 * @return string
	 */
	public function makeFbFriends_post()
	{
		# Get make fb friend parameters
		$user_id		= $this->post('user_id');
		$facebook_id	= $this->post('facebook_id');
		$friend_ids		= $this->post('friend_ids');

		# Check for required parameters
		if( empty($user_id) OR empty($facebook_id) )
		{
			# Return the response with invalid parameters
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# Update facebook id in user table
		$this->api->updateFbId($user_id, $facebook_id);

		# check if friends id is not empty
		if( !empty($friend_ids) )
		{
			# Begin to make fb user follow
			$this->_makeFbFollow($user_id, $friend_ids);
		}

		# Return response with friends sync done
		return $this->response(array(
			'status' 	=> true,
			'message'  	=> 'friend list synchronized successfully'
		), REST_Controller::HTTP_OK);
	}

	// -----------------------------------------------------------------

	/**
	 * logout function - User Logout API
	 * 
	 * @return string
	 */
	public function logout_post()
	{
		# Get user logout data params
		$user_id		= $this->post('user_id');
		$device_id		= $this->post('device_id');
		$device_token	= $this->post('device_token');

		# Check for required parameters to be valid
		if( empty($user_id) OR empty($device_id) OR 
			empty($device_token) )
		{
			//Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# delete device id and token from table
		$this->api->removeDevice($device_token, $device_id);

		# Return the response with user logged out
		return $this->response(array(
			'status' 	=> true,
			'message'  	=> 'user logged out'
		), REST_Controller::HTTP_OK);
	}

	// -----------------------------------------------------------------

	/**
	 * play function - User Song Play API
	 * 
	 * @return string
	 */
	public function play_post()
	{
		# Get user song play data params
		$user_id		= $this->post('user_id');
		$album_id		= $this->post('album_id');
		$album_name		= $this->post('album_name');
		$song_id		= $this->post('song_id');
		$song_name		= $this->post('song_name');
		$song_index		= $this->post('song_index');
		$artist_name	= $this->post('artist_name');
		$song_owner_id	= $this->post('song_owner_id');
		$song_owner_name= $this->post('song_owner_name');

		# Check for parameters to be required
		if( empty($user_id) OR empty($album_id) OR 
			empty($album_name) OR empty($song_id) OR 
			empty($song_name) OR $song_index == "" OR
			empty($artist_name) OR empty($song_owner_id) OR
			empty($song_owner_name) )
		{
			# Return the response with invalid parameters
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# Check for user is already in play list or not
		if( $this->api->hasPlay($user_id) )
		{
			# If aleready in plat list
			# Update user play song in play table
			$is_updated = $this->api->updatePlay($user_id, array(
				'album_id' 		=> $album_id,
				'album_name' 	=> $album_name,
				'song_id' 		=> $song_id,
				'song_name' 	=> $song_name,
				'song_index' 	=> $song_index,
				'artist_name' 	=> $artist_name,
				'song_owner_id' 	=> $song_owner_id,
				'song_owner_name' 	=> $song_owner_name,
				'modify_time' 	=> theDate()
			));

			# If song is updated
			if( $is_updated )
			{
				# Check if play activity exist for user
				if( $this->api->hasPlayActivity($user_id) )
				{
					# If exist
					# Then update play activity data
					$this->api->updatePlayActivity($user_id, array(
						# Json encode and save song play data for activity
						'activity'			=> json_encode(array(
												'album_id' 			=> $album_id,
												'album_name' 		=> $album_name,
												'song_id' 			=> $song_id,
												'song_name' 		=> $song_name,
												'song_index' 		=> $song_index,
												'artist_name' 		=> $artist_name,
												'song_owner_id' 	=> $song_owner_id,
												'song_owner_name' 	=> $song_owner_name
											)),
						'added_ip'			=> theIp(),
						'added_time'		=> theDate()
					));
				}
				else
				{
					# Otherwise
					# Add activity currently playing with song data
					$this->_logActivity(array(
						'id'	=> $user_id,
						'type'	=> 'play',
						# JSON encode activity data
						'act'	=> json_encode(array(
							'album_id' 		=> $album_id,
							'album_name' 	=> $album_name,
							'song_id' 		=> $song_id,
							'song_name' 	=> $song_name,
							'song_index' 	=> $song_index,
							'artist_name' 	=> $artist_name,
							'song_owner_id' 	=> $song_owner_id,
							'song_owner_name' 	=> $song_owner_name,
						))
					));
				}

				# Return the response with song data and its play data
				return $this->response(array(
					'status' 		=> true,
					'message'  		=> 'play updated',
					'song_owner_id'	=> $song_owner_id,
					'song_owner_name'	=> $song_owner_name,
					# Check if it is user favourite
					'is_favour' 	=> $this->api->hasFavour($user_id, $album_id, $song_id),
					# Total count currently playing this song
					'total_count'	=> $this->_currentPlayUser(
											$user_id, $album_id, 
											$song_id, 'count'
										),
					# All name currently playing this song
					'user_names'	=> $this->_currentPlayUser(
											$user_id, $album_id, 
											$song_id, 'names'
										),
				), REST_Controller::HTTP_OK);
			}
		}
		else
		{
			# Otherwise
			# Add entry in play database
			$is_created = $this->api->addPlay(array(
				'user_id' 		=> $user_id,
				'album_id' 		=> $album_id,
				'album_name' 	=> $album_name,
				'song_id' 		=> $song_id,
				'song_name' 	=> $song_name,
				'song_index' 	=> $song_index,
				'artist_name' 	=> $artist_name,
				'song_owner_id' 	=> $song_owner_id,
				'song_owner_name' 	=> $song_owner_name,
				'added_ip' 		=> theIp(),
				'added_time' 	=> theDate(),
				'modify_time' 	=> theDate()
			));

			# If play is created
			if( $is_created )
			{
				# Then
				# Add activity currently playing
				$this->_logActivity(array(
					'id'	=> $user_id,
					'type'	=> 'play',
					# Song data with json encode
					'act'	=> json_encode(array(
						'album_id' 		=> $album_id,
						'album_name' 	=> $album_name,
						'song_id' 		=> $song_id,
						'song_name' 	=> $song_name,
						'song_index' 	=> $song_index,
						'artist_name' 	=> $artist_name,
						'song_owner_id' 	=> $song_owner_id,
						'song_owner_name' 	=> $song_owner_name,
					))
				));

				# Return response with song data play
				return $this->response(array(
					'status' 		=> true,
					'message'  		=> 'play added',
					'song_owner_id'	=> $song_owner_id,
					'song_owner_name'	=> $song_owner_name,
					# Is user favourite song
					'is_favour' 	=> $this->api->hasFavour($user_id, $album_id, $song_id),
					# Total count user is playing
					'total_count'	=> $this->_currentPlayUser(
											$user_id, $album_id, 
											$song_id, 'count'
										),
					# All name user is playing
					'user_names'	=> $this->_currentPlayUser(
											$user_id, $album_id, 
											$song_id, 'names'
										),
				), REST_Controller::HTTP_OK);
			}
		}
	}

	// -----------------------------------------------------------------

	/**
	 * favourite function - Add Or Remove Favourite API
	 * 
	 * @return string
	 */
	public function favourite_post()
	{
		# Get favourite song data params
		$user_id		= $this->post('user_id');
		$album_id		= $this->post('album_id');
		$album_name		= $this->post('album_name');
		$song_id		= $this->post('song_id');
		$song_name		= $this->post('song_name');
		$song_index		= $this->post('song_index');
		$artist_name	= $this->post('artist_name');
		$type			= $this->post('type');

		# Check for parameters to be valid
		if( empty($user_id) OR empty($album_id) OR 
			empty($album_name) OR empty($song_id) OR 
			empty($song_name) OR $song_index == "" OR
			empty($artist_name) OR empty($type) )
		{
			# Return the response with invalid param
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# If add song in favourite list
		if( $type == 'add' )
		{
			# Check if song is already in favourite list
			if( $this->api->hasFavour($user_id, $album_id, $song_id) )
			{
				# return the response already
				return $this->response(array(
					'status' 	=> true,
					'message'  	=> 'song already in favourite'
				), REST_Controller::HTTP_OK);
			}

			# add song in favourite
			$is_added = $this->api->addFavour(array(
				'user_id' 		=> $user_id,
				'album_id' 		=> $album_id,
				'album_name' 	=> $album_name,
				'song_id' 		=> $song_id,
				'song_name' 	=> $song_name,
				'song_index' 	=> $song_index,
				'artist_name' 	=> $artist_name,
				'added_ip' 		=> theIp(),
				'added_time' 	=> theDate()
			));

			# If song added
			if( $is_added )
			{
				# Add activity added favourite
				$this->_logActivity(array(
					'id'	=> $user_id,
					'type'	=> 'favourite',
					'act'	=> json_encode(array(
						'album_id' 		=> $album_id,
						'album_name' 	=> $album_name,
						'song_id' 		=> $song_id,
						'song_name' 	=> $song_name,
						'song_index' 	=> $song_index,
						'artist_name' 	=> $artist_name,
					))
				));

				# return the response
				return $this->response(array(
					'status' 	=> true,
					'message'  	=> 'song added to favourite'
				), REST_Controller::HTTP_OK);
			}
		}
		else
		{
			# Remove song of user from favourite list
			$is_removed = $this->api->removeFavour($user_id, $album_id, $song_id);

			#remove favourite activity
			$this->api->removeFavouriteAct($user_id, $song_id);

			# If song remove from favourite
			if( $is_removed )
			{
				# Return response
				return $this->response(array(
					'status' 	=> true,
					'message'  	=> 'song removed from favourite',
				), REST_Controller::HTTP_OK);
			}
		}
	}

	// -----------------------------------------------------------------

	/**
	 * favouriteList function - get favourite list of user API
	 * 
	 * @return string
	 */
	public function favouriteList_post()
	{
		# Get user id whose favourite list required
		$user_id = $this->post('user_id');

		# Check for parameters to be valid
		if( empty($user_id) )
		{
			# Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# Get user favourite list
		$favourites = $this->api->getFavour($user_id);

		# If record found in user favourite list
		if( $favourites->num_rows() )
		{
			# Set array for output
			$output = array();

			$i = 1;

			# Loop through the song list for favourites
			foreach ($favourites->result() as $one)
			{
				$output[] = $one;
				$i++;
			}

			# Return the response
			return $this->response(array(
				'status' 		=> true,
				'message' 		=> 'favourites listed',
				'total_count'  	=> $favourites->num_rows(),
				'list'			=> $output
			), REST_Controller::HTTP_OK);
		}
		else
		{
			# No any favourite song
			return $this->response(array(
				'status' 		=> false,
				'message' 		=> 'no favourites found',
				'total_count'  	=> $favourites->num_rows(),
			), REST_Controller::HTTP_OK);
		}
	}

	// -----------------------------------------------------------------

	/**
	 * playUserList function - get user playing current song API
	 * 
	 * @return string
	 */
	public function playUserList_post()
	{
		# Get song id whose list required
		$song_id = $this->post('song_id');

		$user_id = $this->post('user_id');

		# Check for parameters to be valid
		if( empty($song_id) OR empty($user_id) )
		{
			# Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# Friend list
		$friends = $this->api->getPlayUserList($song_id, $user_id);

		# If friends found
		if( $friends->num_rows() )
		{
			# Loop through the friend list
			foreach ($friends->result() as $one)
			{
				$is_follow =  $this->api->isFollow($user_id, $one->user_id);

				# Profile pic
				$profile_pic =  !empty($one->profile_picture)
								? base_url('profiles/'.$one->profile_picture)
								: base_url('profiles/'.self::USER_AVATAR);

				# Output data
				$output[] = [
					'user_id'	=> $one->user_id,
					'user_name'	=> $one->user_name,
					'address'	=> $one->address,
					'image'		=> $profile_pic,
					'is_follow'	=> $is_follow
				];
			}

			# response to list friends
			return $this->response(array(
				'status' 		=> true,
				'message'  		=> 'play user listed',
				'total_count'  	=> $friends->num_rows(),
				'list'			=> $output
			), REST_Controller::HTTP_OK);
		}
		else
		{
			# No any friends
			return $this->response(array(
				'status' 		=> false,
				'message'  		=> 'no play users found',
				'total_count'  	=> $friends->num_rows(),
			), REST_Controller::HTTP_OK);
		}
	}

	// -----------------------------------------------------------------

	/**
	 * friendList function - get friend list of user API
	 * 
	 * @return string
	 */
	public function friendList_post()
	{
		# Get user id whose list required
		$user_id = $this->post('user_id');

		# Check for parameters to be valid
		if( empty($user_id) )
		{
			# Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# Friend list
		$friends = $this->api->getUserFriendList($user_id);

		# If friends found
		if( $friends->num_rows() )
		{
			# Loop through the friend list
			foreach ($friends->result() as $one)
			{
				$is_follow =  $this->api->isFollow($user_id, $one->user_id);
				$is_fb_friend =  $this->api->isFbFriend($user_id, $one->user_id);

				# Profile pic
				$profile_pic = !empty($one->profile_picture)
							? base_url('profiles/'.$one->profile_picture)
							: base_url('profiles/'.self::USER_AVATAR);

				# output data
				$output[] = [
					'user_id'		=> $one->user_id,
					'user_name'		=> $one->user_name,
					'address'		=> $one->address,
					'image'			=> $profile_pic,
					'is_follow' 	=> $is_follow,
					'is_fb_friend' 	=> $is_fb_friend,
				];
			}

			# response to list friends
			return $this->response(array(
				'status' 		=> true,
				'message'  		=> 'friends listed',
				'total_count'  	=> $friends->num_rows(),
				'list'			=> $output
			), REST_Controller::HTTP_OK);
		}
		else
		{
			# No any friends
			return $this->response(array(
				'status' 		=> false,
				'message'  		=> 'no friends found',
				'total_count'  	=> $friends->num_rows(),
			), REST_Controller::HTTP_OK);
		}
	}

	// -----------------------------------------------------------------

	/**
	 * friendProfile function - friend profile get API
	 *
	 * @return string
	 */
	public function friendProfile_post()
	{
		# Get user and friend id whose profile required
		$user_id = $this->post('user_id');
		$friend_id = $this->post('friend_id');

		# Check for parameters to be valid
		if( empty($user_id) OR empty($friend_id) )
		{
			# Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# Get friend profile
		$friendPro = $this->api->getFriendProfile($friend_id);

		if( $friendPro->num_rows() )
		{
			$data = $friendPro->row();

			# Profile pic
			$profile_pic = !empty($data->profile_picture)
							? base_url('profiles/'.$data->profile_picture)
							: base_url('profiles/'.self::USER_AVATAR);

			# return friend data
			return $this->response(array(
				'status' 			=> true,
				'message' 			=> 'friend profile listed',
				'user_id'			=> $data->user_id,
				'user_name'			=> $data->user_name,
				'address'			=> $data->address,
				'image'				=> $profile_pic,
				# Is user following flag
				'is_follow'			=> $this->api->isFollow($user_id, $friend_id),
				# Get user favourite count
				'favour_count'		=> $this->api->getFavourCountUser($friend_id),
				# Get user following count
				'following_count' 	=> $this->api->getFollower($friend_id),
				# Get user follower count
				'follower_count'  	=> $this->api->getFollowing($friend_id),
				# User favourite count
				'total_count'		=> $this->api->getFavourCountUser($friend_id),
				# User favourite list
				'list'  			=> $this->_favourListOfFriend($friend_id)
			), REST_Controller::HTTP_OK);
		}
		else
		{
			# No any favourite song
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'friend not found',
			), REST_Controller::HTTP_OK);
		}
	}

	// -----------------------------------------------------------------

	/**
	 * follower function - follow / unfollow users API
	 *
	 * @return string
	 */
	public function follower_post()
	{
		# Get user and follow id and type
		$user_id 	= $this->post('user_id');
		$follow_id 	= $this->post('follow_id');
		$type 		= $this->post('type');

		# Check for parameters to be valid
		if( empty($user_id) OR empty($follow_id) OR empty($type) )
		{
			# Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# Check if follower exist or not
		if( ! $this->api->hasUser($follow_id) )
		{
			# Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'follower does not exist'
			), REST_Controller::HTTP_OK);
		}

		# if type is add to add follower
		if( $type == 'add' )
		{
			# Check if already following
			if( $this->api->isFollow($user_id, $follow_id) )
			{
				return $this->response(array(
					'status' 	=> true,
					'message'  	=> 'already following'
				), REST_Controller::HTTP_OK);
			}

			$is_added = $this->api->addFollower(array(
				'user_id'		=> $user_id,
				'follow_id'		=> $follow_id,
				'is_fb_friend'	=> 0,
				'added_ip'		=> theIp(),
				'added_time'	=> theDate()
			));

			# If follower added
			if( $is_added )
			{
				# Add activity added favourite
				$this->_logActivity(array(
					'id'	=> $user_id,
					'type'	=> 'follow',
					'act'	=> json_encode(array(
						'follow_id' 	=> $follow_id,
						'follow_name'	=> $this->api->getUserName($follow_id)
					))
				));

				# return the response
				return $this->response(array(
					'status' 	=> true,
					'message'  	=> 'follower added'
				), REST_Controller::HTTP_OK);
			}
			else
			{
				# return the response
				return $this->response(array(
					'status' 	=> false,
					'message'  	=> 'unable to add follower'
				), REST_Controller::HTTP_OK);
			}
		}

		# If follower remove
		if( $type == 'remove' )
		{
			# Remove follower
			$is_removed = $this->api->removeFollower($user_id, $follow_id);

			#remove follow activity
			$this->api->removeFollowAct($user_id, $follow_id);

			//If follower added
			if( $is_removed )
			{
				# return the response
				return $this->response(array(
					'status' 	=> true,
					'message'  	=> 'follower removed'
				), REST_Controller::HTTP_OK);
			}

			# return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'follower not removed'
			), REST_Controller::HTTP_OK);
		}
	}

	// -----------------------------------------------------------------

	/**
	 * getSetting function - get user setting API
	 *
	 * @return string
	 */
	public function getSetting_post()
	{
		# Get parameters
		$user_id = $this->post('user_id');
		$device_id = $this->post('device_id');
		$device_token = $this->post('device_token');

		# Check for parameters to be valid
		if( empty($user_id) OR empty($device_id) OR empty($device_token) )
		{
			# Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# Check if has device return notification on
		if( $this->api->hasDevice($device_token, $device_id) != FALSE )
		{
			# Return the response
			return $this->response(array(
				'status' 		=> true,
				'notification'  => true
			), REST_Controller::HTTP_OK);
		}
		else
		{
			# Return the response
			return $this->response(array(
				'status' 		=> true,
				'notification'  => false
			), REST_Controller::HTTP_OK);
		}
	}

	// -----------------------------------------------------------------

	/**
	 * notify function - notification status change API
	 *
	 * @return string
	 */
	public function notify_post()
	{
		# Get notification status and data
		$status = $this->post('status');
		$user_id = $this->post('user_id');
		$device_id = $this->post('device_id');
		$device_token = $this->post('device_token');

		# Check for parameters to be valid
		if( empty($status) OR empty($user_id) OR
			empty($device_id) OR empty($device_token) )
		{
			# Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# If type is on
		if( $status == 'on' )
		{
			# Check if device already added or not
			if( $this->api->hasDevice($device_token, $device_id) == FALSE )
			{
				# Create device add in database
				$is_added = $this->api->addDevice(array(
					'user_id' 			=> $user_id,
					'device_token' 		=> $device_token,
					'device_id' 		=> $device_id,
					'added_ip' 			=> theIp(),
					'added_time' 		=> theDate(),
					'modify_time' 		=> theDate(),
				));
			}

			# return the response
			return $this->response(array(
				'status' 	=> true,
				'message'  	=> 'notification on'
			), REST_Controller::HTTP_OK);
		}
		
		# If off
		if( $status == 'off' )
		{
			# Delete device
			$is_removed = $this->api->removeDevice($device_token, $device_id);

			if( $is_removed )
			{
				# return the response
				return $this->response(array(
					'status' 	=> true,
					'message'  	=> 'notification off'
				), REST_Controller::HTTP_OK);
			}
		}
	}

	// -----------------------------------------------------------------

	/**
	 * updateProfile function - get user profile ONLY current user API
	 *
	 * @return string
	 */
	public function userProfile_post()
	{
		# Get user id whose profile want to get
		$user_id = $this->post('user_id');

		# Check for parameters to be valid
		if( empty($user_id) )
		{
			# Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# Get user profile
		$userPro = $this->api->getFriendProfile($user_id);

		if( $userPro->num_rows() )
		{
			$data = $userPro->row();

			# Profile pic
			$profile_pic = !empty($data->profile_picture)
							? base_url('profiles/'.$data->profile_picture)
							: base_url('profiles/'.self::USER_AVATAR);

			# return friend data
			return $this->response(array(
				'status' 			=> true,
				'message' 			=> 'user profile listed',
				'user_id'			=> $data->user_id,
				'user_name'			=> $data->user_name,
				'address'			=> $data->address,
				'image'				=> $profile_pic,
				# User favourite count
				'favour_count'		=> $this->api->getFavourCountUser($user_id),
				# User following count
				'following_count' 	=> $this->api->getFollower($user_id),
				# User follower count
				'follower_count'  	=> $this->api->getFollowing($user_id),
				# User favourite count
				'total_count'		=> $this->api->getFavourCountUser($user_id),
				# User song list
				'list'  			=> $this->_favourListOfFriend($user_id)
			), REST_Controller::HTTP_OK);
		}
		else
		{
			# No any favourite song
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'user not found',
			), REST_Controller::HTTP_OK);
		}
	}

	// -----------------------------------------------------------------

	/**
	 * updateProfile function - update user profile API
	 *
	 * @return string
	 */
	public function updateProfile_post()
	{
		# Get user profile update data
		$user_id 	= $this->post('user_id');
		$user_name 	= $this->post('user_name');
		$address 	= $this->post('address');

		# Check for parameters to be valid
		if( empty($user_id) OR empty($user_name) )
		{
			# Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# update user profile
		$is_updated = $this->api->updateProfile($user_id, array(
			'user_name'	=> $user_name,
			'address'	=> isset($address) ? $address : ''
		));

		# If notification status updated
		if( $is_updated )
		{
			# return the response
			return $this->response(array(
				'status' 	=> true,
				'message'  	=> 'user details updated',
				'user_name'	=> $this->api->getUserName($user_id),
				'address'	=> $this->api->getUserAddr($user_id)
			), REST_Controller::HTTP_OK);
		}
	}

	// -----------------------------------------------------------------

	/**
	 * uploadPicture function - upload user profile picture API
	 *
	 * @return string
	 */
	public function uploadPicture_post()
	{
		# User id whose picture uploading
		$user_id = $this->post("user_id");

		# Check for parameters to be valid
		if( empty($user_id) )
		{
			# Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# Upload configs
		$config['upload_path']		= './profiles/';
        $config['allowed_types']	= 'gif|jpg|png|jpeg';
        $config['file_name']		= md5(uniqid());

        # upload library
        $this->load->library('upload', $config);

        # If profile not uploaded
        if ( ! $this->upload->do_upload('user_pic'))
        {
			# Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> $this->upload->display_errors('', '')
			), REST_Controller::HTTP_BAD_REQUEST);
        }
        else
        {
        	# Update picture in database
        	$this->api->updatePic(
        		$user_id,
        		$this->upload->data('file_name')
        	);

			# Return the response
			return $this->response(array(
				'status' 	=> true,
				'message'  	=> 'profile picture updated',
				'image'		=> base_url('profiles/') . $this->upload->data('file_name'),
				'user_name'	=> $this->api->getUserName($user_id),
				'address'	=> $this->api->getUserAddr($user_id)
			), REST_Controller::HTTP_OK);
        }
	}

	// -----------------------------------------------------------------

	/**
	 * getActivity function - get user activity of play follow favourite API
	 *
	 * @return string
	 */
	public function getActivity_post()
	{
		# Get user id and page number
		$user_id = $this->post("user_id");
		$page_no = $this->post("page_no");

		# Check for parameters to be valid
		if( empty($user_id) )
		{
			# Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'Invalid parameters'
			), REST_Controller::HTTP_BAD_REQUEST);
		}

		# Get all ids which user follow and following user
		$allIDs = $this->api->getUserFollowId($user_id);

		# If empty ids then
		if( empty($allIDs) )
		{
			$actIds = 0;
		}
		else
		{	
			# Otherwise
			$actIds = $allIDs;
		}

		# Check for page
		if( !empty($page_no) )
		{
			$page = intval($page_no) - 1;
		}
		else
		{
			$page = 0;
		}

		# Get all activity results
		$actResult = $this->api->getUserActivity($actIds, $page*20);

		# Get user activity count
		$actCount = $this->api->getUserActivityCount($actIds);

		# If result found
		if( $actResult->num_rows() )
		{
			# Loop through all activity
			foreach ($actResult->result() as $one)
			{
				# Current time
				$currenttime = date("Y-m-d H:i:s");

				# Time before 6 minutes
				$timebefore = strtotime("-6 minutes ", strtotime($currenttime));

				# For play activity to show only 6 min before
				if( $one->activity_type == 'play' )
				{
					# Check if play activity time is grater than 6 min before time
					if( strtotime($one->added_time) >= $timebefore  )
					{
						# For name to be updated
						$songActData = (array) json_decode($one->activity);

						# Remove old one
						unset($songActData['song_owner_name']);

						# Set new one
						$songActData['song_owner_name'] = $this->api->getUserName($songActData['song_owner_id']);

						# Output data
						$output[] = array(
							'user_id'			=> $one->user_id,
							'name'				=> $this->api->getUserName($one->user_id),
							'image'				=> $this->api->getUserPic($one->user_id),
							'type'				=> $one->activity_type,
							'data'				=> $songActData,
							'following_count' 	=> $this->api->getFollower($one->user_id),
							'follower_count'  	=> $this->api->getFollowing($one->user_id),
							'time'				=> $one->added_time
						);
					}
				}
				else
				{
					if( $one->activity_type == 'follow' )
					{
						# For name to be updated
						$ActData = (array) json_decode($one->activity);

						# Remove old one
						unset($ActData['follow_name']);

						# Set new one
						$ActData['follow_name'] = $this->api->getUserName($ActData['follow_id']);	
					}
					else
					{
						$ActData = (array) json_decode($one->activity);
					}

					# Output data
					$output[] = array(
						'user_id'			=> $one->user_id,
						'name'				=> $this->api->getUserName($one->user_id),
						'image'				=> $this->api->getUserPic($one->user_id),
						'type'				=> $one->activity_type,
						'data'				=> $ActData,
						'following_count' 	=> $this->api->getFollower($one->user_id),
						'follower_count'  	=> $this->api->getFollowing($one->user_id),
						'time'				=> $one->added_time
					);
				}
			}

			# Return the response
			return $this->response(array(
				'status' 			=> true,
				'message'  			=> 'activity listed',
				'total_count' 		=> ceil($actCount/20),
				'current_page'		=> intval($page) + 1,
				'list'				=> $output
			), REST_Controller::HTTP_OK);
		}
		else
		{
			# If no result found
			# Return the response
			return $this->response(array(
				'status' 	=> false,
				'message'  	=> 'no activity found'
			), REST_Controller::HTTP_OK);
		}
	}

	// -----------------------------------------------------------------

	/**
	 * _logActivity function - log user activity
	 *
	 * @access private
	 * @param $act | array | activity data
	 * @return void
	 */
	private function _logActivity(Array $act)
	{
		# If array of activity then
		if( is_array($act) )
		{
			# Add activity to db
			$this->api->addActivity(array(
				'user_id'		=> $act['id'],
				'activity_type'	=> $act['type'],
				'activity'		=> $act['act'],
				'added_ip'		=> theIp(),
				'added_time'	=> theDate()
			));
		}
	}

	// -----------------------------------------------------------------

	/**
	 * _favourListOfFriend function - get users favourite list
	 *
	 * @access private
	 * @param $friend_id | varchar | friend id
	 * @return array or boolean | Songs data
	 */
	private function _favourListOfFriend($friend_id)
	{
		# List of favourite
		$list = $this->api->getFavour($friend_id);

		# If found
		if( $list->num_rows() )
		{
			# Loop through the song list for favourites
			foreach ($list->result() as $one)
			{
				$output[] = [
					'user_id' 			=> $one->user_id,
					'album_id' 			=> $one->album_id,
					'album_name' 		=> $one->album_name,
					'song_id' 			=> $one->song_id,
					'song_name' 		=> $one->song_name,
					'song_index' 		=> $one->song_index,
					'artist_name' 		=> $one->artist_name,
					'favourite_count' 	=> $this->api->getFavourCount($one->album_id, $one->song_id)
				];
			}
			return $output;
		}
		else
		{
			return [];
		}
	}

	// -----------------------------------------------------------------

	/**
	 * _currentPlayUser function - find which user is currently playing the song
	 *
	 * @access private
	 * @param $user_id | varchar | user id
	 * @param $album_id | varchar | album id
	 * @param $song_id | varchar | song id
	 * @param $return | string | count or 
	 * @return string or int | usernames or count
	 */
	private function _currentPlayUser($user_id, $album_id, $song_id, $return = 'count')
	{
		# Get current play users of songs data
		$current = $this->api->currentPlayUsers($user_id, $album_id, $song_id);

		# Check if any user playing
		if( $current->num_rows() )
		{
			# Set variable for user names
			$userNames = '';

			# Loop through users playing song
			foreach ($current->result() as $one)
			{
				# Saparate username with comma and space
				$userNames .= rtrim($one->user_name, ' ');
				$userNames .= ', ';
			}

			# If $return is count return number of users otherwise name
			if( $return == 'count' )
			{
				return $current->num_rows();
			}
			return rtrim($userNames, ', ');
		}
		else
		{
			# If no user found which play
			# If $return is count return 0 otherwise blank
			if( $return == 'count' )
			{
				return 0;
			}
			return '';
		}
	}

	// -----------------------------------------------------------------

	/**
	 * _makeFbFollow function - make friend to fb friends
	 *
	 * @access private
	 * @param $user_id | varchar | user id
	 * @param $friend_ids | varchar | facebook ids
	 * @return void
	 */
	private function _makeFbFollow($user_id, $friend_ids)
	{
		# Create array of all friend ids
		$totalIds = explode(',', $friend_ids);

		# Loop through all friend ids
		foreach ($totalIds as $one)
		{
			# get user id by fb id
			$follow_id = $this->_getUserIdByFb($one);

			# Check if not already following that
			if( ! $this->api->isFollow($user_id, $follow_id) && !empty($follow_id) )
			{
				# Add to follow list of user
				$this->api->addFollower(array(
					'user_id'		=> $user_id,
					'follow_id'		=> $follow_id,
					'is_fb_friend'	=> 1,
					'added_ip'		=> theIp(),
					'added_time'	=> theDate()
				));
			}
		}
	}

	// -----------------------------------------------------------------

	/**
	 * _getUserIdByFb function - get user id by facebook id
	 *
	 * @access private
	 * @param $fb_id | varchar | facebook id
	 * @return mixed
	 */
	private function _getUserIdByFb($fb_id)
	{
		return $this->api->userIdByFbId($fb_id);
	}

	// -----------------------------------------------------------------
}

// ----------------------------------------------
// END API CONTROLLER
// ----------------------------------------------
