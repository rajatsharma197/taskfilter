<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// MY Main controller extends CI controller
class MY_Controller extends CI_Controller
{
	//Constructor
	public function __construct()
	{
		parent::__construct();
		//Load model
		$this->load->model('api_model', 'api');
	}
}
