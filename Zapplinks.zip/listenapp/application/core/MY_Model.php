<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * MY Main Model extends CI Model
 */
class MY_Model extends CI_Model
{
	//Constructor
	public function __construct()
	{
		parent::__construct();
		//Load databse
		$this->load->database();
	}
}