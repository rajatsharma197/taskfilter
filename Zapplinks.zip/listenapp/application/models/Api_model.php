<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Api main model
 */
class Api_model extends MY_Model
{
	/**
	 * @const USER_TBL user table
	 */
	const USER_TBL		= 'la_user';

	/**
	 * @const PLAY_TBL song play table
	 */
	const PLAY_TBL		= 'la_playing';

	/**
	 * @const FOLL_TBL user follows table
	 */
	const FOLL_TBL		= 'la_follows';

	/**
	 * @const FAVO_TBL favourite table
	 */
	const FAVO_TBL 		= 'la_user_fav';

	/**
	 * @const DEVICE_TBL device info table
	 */
	const DEVICE_TBL 	= 'la_devices';

	/**
	 * @const ACT_TBL user activity table
	 */
	const ACT_TBL 		= 'la_user_activity';
	
	/**
	 * @const USER_AVATAR default picture
	 */
	const USER_AVATAR 	= 'user_avatar.png';

	// ---------------------------------------------------------------------

	/**
	 * __construct 	- Constructor function
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
	}

	// ---------------------------------------------------------------------

	/**
	 * hasUser 		- Check if user exist
	 *
	 * @param varchar 	| $user_id 	| spotify user id
	 * @return boolean
	 */
	public function hasUser($user_id)
	{
		# Get user with user id
		$q = $this->db
				  ->where('user_id', $user_id)
				  ->limit(1)
				  ->get(self::USER_TBL);

		# Check if user data found and return
		if( $q->num_rows() )
		{
			return TRUE;
		}

		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * hasDevice 		- Check if device exist
	 *
	 * @param varchar 	| $device_token | user device token
	 * @param string 	| $device_id 	| user device id ios or android
	 * @return int
	 */
	public function hasDevice($device_token, $device_id)
	{
		# Get details from db
		$q = $this->db
				  ->where(array(
				  		'device_token'	=> $device_token,
				  		'device_id'		=> $device_id,
				  	))
				  ->limit(1)
				  ->get(self::DEVICE_TBL);

		# Check if record found and return
		if( $q->num_rows() )
		{
			return $q->row()->ID;
		}
		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * addDevice 		- Add user device data
	 *
	 * @param array 	| $data 	| user device data
	 * @return boolean
	 */
	public function addDevice($data)
	{
		# Insert in db
		$q = $this->db
				  ->insert(self::DEVICE_TBL, $data);

		# Check if inserted
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}

		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * removeDevice 	- Remove device from database
	 *
	 * @param varchar 	| $device_token | device token
	 * @param string 	| $device_id 	| device id ios or android
	 * @return boolean
	 */
	public function removeDevice($device_token, $device_id)
	{
		# Delete device data
		$q = $this->db
				  ->where(array(
				  		'device_token' 	=> $device_token,
				  		'device_id'	 	=> $device_id
				  	))
				  ->delete(self::DEVICE_TBL);

		# Check if device deleted
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}

		return TRUE;
	}

	// ---------------------------------------------------------------------

	/**
	 * updateDevice 	- update device in database
	 *
	 * @param array | $data | user device data
	 * @param int 	| $ID 	| record id
	 * @return boolean
	 */
	public function updateDevice($data, $ID)
	{
		# Update device data
		$q = $this->db
				  ->where('ID', $ID)
				  ->update(self::DEVICE_TBL, $data);

		# Check if updated
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}

		return TRUE;
	}

	// ---------------------------------------------------------------------

	/**
	 * updateUser 	- update user in database
	 *
	 * @param varchar 	| $user_id 		| user unique id
	 * @param array 	| $user_data 	| user data
	 * @return object
	 */
	public function updateUser($user_id, $user_data)
	{
		# Update user information
		$q = $this->db
				  ->where('user_id', $user_id)
				  ->update(self::USER_TBL, $user_data);

		# get user data object
		$data = $this->db
					 ->select(array('user_name', 'address', 'profile_picture'))
				  	 ->where('user_id', $user_id)
				  	 ->limit(1)
				  	 ->get(self::USER_TBL)
				  	 ->row();

		return $data;
	}

	// ---------------------------------------------------------------------

	/**
	 * addUser 		- add user in database
	 *
	 * @param array 	| $user_data 	| user data
	 * @return boolean
	 */
	public function addUser($user_data)
	{
		# Insert user record
		$q = $this->db
				  ->insert(self::USER_TBL, $user_data);

		# Check if user created
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}

		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * hasPlay 		- check if user play exist
	 *
	 * @param varchar 	| $user_id 		| user unique id
	 * @return boolean
	 */
	public function hasPlay($user_id)
	{
		# Get user with user id
		$q = $this->db
				  ->where('user_id', $user_id)
				  ->get(self::PLAY_TBL);

		# Check if exist
		if( $q->num_rows() )
		{
			return TRUE;
		}

		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * addPlay 		- check if user play exist
	 *
	 * @param array 	| $song_data 		| play song data
	 * @return boolean
	 */
	public function addPlay($song_data)
	{
		# Add play song
		$q = $this->db
				  ->insert(self::PLAY_TBL, $song_data);

		# Check if play created
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}

		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * updatePlay 		- update play song for user
	 *
	 * @param varchar 	| $user_id 		| user unique id
	 * @param array 	| $song_data 	| play song data
	 * @return boolean
	 */
	public function updatePlay($user_id, $song_data)
	{
		# Update play information
		$q = $this->db
				  ->where('user_id', $user_id)
				  ->update(self::PLAY_TBL, $song_data);

		# Check if play updated
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}

		return TRUE;
	}

	// ---------------------------------------------------------------------

	/**
	 * hasFavour 		- check if has song in favourite
	 *
	 * @param varchar 	| $user_id 		| user unique id
	 * @param varchar 	| $album_id 	| album unique id
	 * @param varchar 	| $song_id 		| song unique id
	 * @return boolean
	 */
	public function hasFavour($user_id, $album_id, $song_id)
	{
		# Get favourite data
		$q = $this->db
				  ->where(array(
					  	'user_id' 	=> $user_id, 
					  	'album_id' 	=> $album_id, 
					  	'song_id' 	=> $song_id
				  	))
				  ->get(self::FAVO_TBL);

		# Check if favorite available in table
		if( $q->num_rows() )
		{
			return TRUE;
		}

		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * addFavour 		- add song in user favourite list
	 *
	 * @param array 	| $favour_data 	| favourite song data
	 * @return boolean
	 */
	public function addFavour($favour_data)
	{
		# add in favourite list
		$q = $this->db
				  ->insert(self::FAVO_TBL, $favour_data);

		# Check if favourite created
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}

		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * removeFavour 	- remove song from user favourite list
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @param varchar 	| $album_id | album unique id
	 * @param varchar 	| $song_id 	| song unique id
	 * @return boolean
	 */
	public function removeFavour($user_id, $album_id, $song_id)
	{
		# remove favourite
		$q = $this->db
				  ->where(array(
				  		'user_id' 	=> $user_id, 
				  		'album_id' 	=> $album_id, 
				  		'song_id' 	=> $song_id
				  	))
				  ->delete(self::FAVO_TBL);

		# Check if favourite removed
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}

		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * getFavour 	- get user favourite list
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @return object
	 */
	public function getFavour($user_id)
	{
		# Get favourite data
		$q = $this->db
				  ->select(array(
				  		'user_id', 
				  		'album_id', 
				  		'album_name', 
				  		'song_id', 
				  		'song_name', 
				  		'song_index', 
				  		'artist_name'))
				  ->where('user_id', $user_id)
				  ->order_by('ID', 'DESC')
				  ->get(self::FAVO_TBL);

		return $q;
	}

	// ---------------------------------------------------------------------

	/**
	 * getPlayUserList 	- get current song play user list
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @param varchar 	| $song_id 	| song unique id
	 * @return object
	 */
	public function getPlayUserList($song_id, $user_id)
	{
		# Get play users
		$q = $this->db->query("
				SELECT la_user.user_id, la_user.user_name, la_user.address, la_user.profile_picture
				FROM `la_user` LEFT JOIN `la_playing` ON la_user.user_id = la_playing.user_id 
				WHERE la_playing.song_id = '{$song_id}' AND la_user.user_id != '{$user_id}' 
				ORDER BY la_playing.ID DESC
			");

		return $q;
	}

	// ---------------------------------------------------------------------

	/**
	 * getUserFriendList 	- get user friends list both followers and followings
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @return object
	 */
	public function getUserFriendList($user_id)
	{
		# Set array to hold ids
		$ids = array();

		# Get follow ids which user follow
		$q_f = $this->db
					->select('follow_id')
					->where('user_id', $user_id)
					->get(self::FOLL_TBL);

		# Check if records found
		if( $q_f->num_rows() )
		{
			foreach ($q_f->result() as $one)
			{
				# Add in array
				array_push($ids, $one->follow_id);
			}
		}

		# Get user ids which following user
		$q_s = $this->db
					->select('user_id')
					->where('follow_id', $user_id)
					->get(self::FOLL_TBL);

		# Check if records found
		if( $q_s->num_rows() )
		{
			foreach ($q_s->result() as $one)
			{
				# add in array
				array_push($ids, $one->user_id);
			}
		}

		# Check if not empty ids
		if( !empty($ids) && count($ids) )
		{
			# select unique values
			$ids = array_unique($ids);
			# Sparate them with comma
			$allIds = implode(',', $ids);
		}
		else
		{
			# Otherwise set zero
			$allIds = 0;
		}

		# Get all ids user data
		$q = $this->db->query("
				SELECT user_id, user_name, 
						address, profile_picture
				FROM `la_user` 
				WHERE FIND_IN_SET(user_id, '{$allIds}') 
				ORDER BY ID DESC
			");

		return $q;
	}

	// ---------------------------------------------------------------------

	/**
	 * getFriendProfile 	- user profiles NOT for current user
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @return object
	 */
	public function getFriendProfile($user_id)
	{
		//Get user with user id
		$q = $this->db
				  ->select('*')
				  ->limit(1)
				  ->where('user_id', $user_id)
				  ->get(self::USER_TBL);

		return $q;
	}

	// ---------------------------------------------------------------------

	/**
	 * getFavourCount 	- get song favourite count
	 *
	 * @param varchar 	| $album_id 	| album unique id
	 * @param varchar 	| $song_id 		| song unique id
	 * @return int
	 */
	public function getFavourCount($album_id, $song_id)
	{
		# Get total count song
		$q = $this->db
				  ->where(array('album_id' => $album_id,'song_id' => $song_id))
				  ->from(self::FAVO_TBL)
				  ->count_all_results();

		return $q;
	}
	// ---------------------------------------------------------------------

	/**
	 * getFavourCountUser 	- get user favourites count
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @return int
	 */
	public function getFavourCountUser($user_id)
	{
		# Get user favourite count
		$q = $this->db
				  ->where('user_id', $user_id)
				  ->from(self::FAVO_TBL)
				  ->count_all_results();

		return $q;
	}

	// ---------------------------------------------------------------------

	/**
	 * getFollower 	- get followers count of user
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @return int
	 */
	public function getFollower($user_id)
	{
		# Get follower count
		$q = $this->db
				  ->where('user_id', $user_id)
				  ->from(self::FOLL_TBL)
				  ->count_all_results();

		return $q;
	}

	// ---------------------------------------------------------------------

	/**
	 * getFollowing 	- get following count of user
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @return int
	 */
	public function getFollowing($user_id)
	{
		# Get following count
		$q = $this->db
				  ->where('follow_id', $user_id)
				  ->from(self::FOLL_TBL)
				  ->count_all_results();

		return $q;
	}

	// ---------------------------------------------------------------------

	/**
	 * addFollower 	- add follower of user
	 *
	 * @param array 	| $follow_data 	| follow data
	 * @return boolean
	 */
	public function addFollower($follow_data)
	{
		# Create follower
		$q = $this->db
				  ->insert(self::FOLL_TBL, $follow_data);

		# Check if follower created
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}

		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * removeFollower 	- remove follower of user
	 *
	 * @param varchar 	| $user_id 		| user unique id
	 * @param varchar 	| $follow_id 	| user unique id
	 * @return boolean
	 */
	public function removeFollower($user_id, $follow_id)
	{
		$q = $this->db
				  ->where(array('user_id' => $user_id, 'follow_id' => $follow_id))
				  ->delete(self::FOLL_TBL);

		# Check if favourite removed
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}

		return TRUE;
	}

	// ---------------------------------------------------------------------

	/**
	 * updateProfile 	- update user profile
	 *
	 * @param varchar 	| $user_id 		| user unique id
	 * @param varchar 	| $user_data 	| user update data
	 * @return boolean
	 */
	public function updateProfile($user_id, $user_data)
	{
		# Update user information
		$q = $this->db
				  ->where('user_id', $user_id)
				  ->update(self::USER_TBL, $user_data);

		# Check if user updated
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}

		return TRUE;
	}

	// ---------------------------------------------------------------------

	/**
	 * updateProfile 	- check if user in follow list
	 *
	 * @param varchar 	| $user_id 		| user unique id
	 * @param varchar 	| $follow_id 	| user unique id
	 * @return boolean
	 */
	public function isFollow($user_id, $follow_id)
	{
		$q = $this->db
		 		  ->select('user_id')
				  ->where(array(
				  		'user_id' => $user_id, 
				  		'follow_id' => $follow_id
				  	))
				  ->get(self::FOLL_TBL);

		# If follow
		if( $q->num_rows() )
		{
			return TRUE;
		}

		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * isFbFriend 	- check if user is fb friend
	 *
	 * @param varchar 	| $user_id 		| user unique id
	 * @param varchar 	| $follow_id 	| user unique id
	 * @return boolean
	 */
	public function isFbFriend($user_id, $follow_id)
	{
		$q = $this->db
		 		  ->select('is_fb_friend')
				  ->where(array('user_id' => $user_id, 'follow_id' => $follow_id))
				  ->limit(1)
				  ->get(self::FOLL_TBL);

		# If has data
		if( $q->num_rows() )
		{
			# If fb friend
			if( $q->row()->is_fb_friend == 1 )
			{
				return TRUE;
			}
		}

		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * currentPlayUsers 	- get current play user list with details
	 *
	 * @param varchar 	| $user_id 		| user unique id
	 * @param varchar 	| $album_id 	| album unique id
	 * @param varchar 	| $song_id 		| song unique id
	 * @return object
	 */
	public function currentPlayUsers($user_id, $album_id, $song_id)
	{

		//get play users id
		$q = $this->db->query("
				SELECT la_user.user_id, la_user.user_name
				FROM `la_user` LEFT JOIN `la_playing` ON la_user.user_id = la_playing.user_id 
				WHERE la_playing.song_id = '{$song_id}' 
				AND la_playing.album_id = '{$album_id}' 
				AND la_user.user_id != '{$user_id}';
			");

		//If playing
		return $q;
	}

	// ---------------------------------------------------------------------

	/**
	 * updatePic 	- update user profile picture
	 *
	 * @param varchar 	| $user_id 		| user unique id
	 * @param varchar 	| $file_name 	| image file name
	 * @return boolean
	 */
	public function updatePic($user_id, $file_name)
	{
		$this->db
			 ->where('user_id', $user_id)
			 ->update(self::USER_TBL, array('profile_picture' => $file_name));

		# If updated
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}
		return TRUE;
	}

	// ---------------------------------------------------------------------

	/**
	 * updateFbId 	- update facebook id of user
	 *
	 * @param varchar 	| $user_id 		| user unique id
	 * @param varchar 	| $facebook_id 	| user fb id
	 * @return boolean
	 */
	public function updateFbId($user_id, $facebook_id)
	{
		$this->db
			 ->where('user_id', $user_id)
			 ->update(self::USER_TBL, array('facebook_id' => $facebook_id));

		# If updated
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}
		return TRUE;
	}

	// ---------------------------------------------------------------------

	/**
	 * userIdByFbId 	- get user id by facebook id
	 *
	 * @param varchar 	| $facebook_id 	| user fb id
	 * @return varchar
	 */
	public function userIdByFbId($fb_id)
	{
		$q = $this->db
				  ->select('user_id')
				  ->where('facebook_id', $fb_id)
				  ->limit(1)
				  ->get(self::USER_TBL);

		if( $q->num_rows() )
		{
			return $q->row()->user_id;
		}
		return '';
	}

	// ---------------------------------------------------------------------

	/**
	 * getUserFollowId 	- get all id which user follow or following user
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @return string
	 */
	public function getUserFollowId($user_id)
	{
		# Select ids which user follow
		$q = $this->db
				  ->select('follow_id')
				  ->where('user_id', $user_id)
				  ->get(self::FOLL_TBL);

		# Select ids which following user
		$q_n = $this->db
				  ->select('user_id')
				  ->where('follow_id', $user_id)
				  ->get(self::FOLL_TBL);

		# Define array to store ids
		$ids = array();

		# Push follow ids to array
		if( $q->num_rows() )
		{
			foreach ($q->result() as $one)
			{
				array_push($ids, $one->follow_id);
			}
		}

		# Push following ids to array
		if( $q_n->num_rows() )
		{
			foreach ($q_n->result() as $one)
			{
				array_push($ids, $one->user_id);
			}
		}

		# If not empty id then return all ids
		if( !empty($ids) )
		{
			# Clear duplicate ids
			$ids = array_unique($ids);
			return implode(',', $ids);
		}

		return '';
	}

	// ---------------------------------------------------------------------

	/**
	 * getUserActivity 	- get all activity of user play follow favourite
	 *
	 * @param varchar 	| $act_ids 	| user unique ids
	 * @param int 		| $offset 	| offset
	 * @return object
	 */
	public function getUserActivity($act_ids, $offset)
	{
		# Get activity data
		$q = $this->db
				  ->query("SELECT `user_id`, `activity_type`, `activity`, `added_time`
				  		   FROM `la_user_activity` 
				  		   WHERE FIND_IN_SET(user_id, '{$act_ids}') ORDER BY `added_time` DESC
				  		   LIMIT {$offset}, 20");

		return $q;
	}

	// ---------------------------------------------------------------------

	/**
	 * getUserActivityCount 	- get count of user activity
	 *
	 * @param varchar 	| $act_ids 	| user unique ids
	 * @return int
	 */
	public function getUserActivityCount($act_ids)
	{
		$q = $this->db
				  ->query("SELECT `user_id`, `activity_type`, `activity`, `added_time`
				  		   FROM `la_user_activity` 
				  		   WHERE FIND_IN_SET(user_id, '".$act_ids."') ORDER BY `ID` DESC");

		# Number of records
		return $q->num_rows();
	}

	// ---------------------------------------------------------------------

	/**
	 * getUserName 	- get user name by id
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @return string
	 */
	public function getUserName($user_id)
	{
		return $this->db
					->select('user_name')
					->where('user_id', $user_id)
					->get(self::USER_TBL)
					->row()
					->user_name;
	}

	// ---------------------------------------------------------------------

	/**
	 * getUserAddr 	- get user address by id
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @return string
	 */
	public function getUserAddr($user_id)
	{
		return $this->db
					->select('address')
					->where('user_id', $user_id)
					->get(self::USER_TBL)
					->row()
					->address;
	}

	// ---------------------------------------------------------------------

	/**
	 * getUserPic 	- get user profile picture by id
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @return varchar
	 */
	public function getUserPic($user_id)
	{
		$q = $this->db
				  ->select('profile_picture')
				  ->where('user_id', $user_id)
				  ->limit(1)
				  ->get(self::USER_TBL);

		if( $q->num_rows() )
		{
			# Profile pic or default
			$profile_pic = !empty($q->row()->profile_picture)
						? base_url('profiles/'.$q->row()->profile_picture)
						: base_url('profiles/'.self::USER_AVATAR);

			return $profile_pic;
		}

		return base_url('profiles/'.self::USER_AVATAR);
	}

	// ---------------------------------------------------------------------

	/**
	 * addActivity 	- add activity of user
	 *
	 * @param array 	| $act_data 	| activity data
	 * @return boolean
	 */
	public function addActivity($act_data)
	{
		$q = $this->db
				  ->insert(self::ACT_TBL, $act_data);

		# Check if activity created
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}

		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * hasPlayActivity 	- check if play activity for user exist
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @return boolean
	 */
	public function hasPlayActivity($user_id)
	{
		$q = $this->db
				  ->where('user_id', $user_id)
				  ->get(self::ACT_TBL);

		# If found
		if( $q->num_rows() )
		{
			return TRUE;
		}
		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * updatePlayActivity 	- if play activity exist update
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @param varchar 	| $data 	| play song data
	 * @return boolean
	 */
	public function updatePlayActivity($user_id, $data)
	{
		$q = $this->db
				  ->where(array('user_id' => $user_id, 'activity_type' => 'play'))
				  ->update(self::ACT_TBL, $data);

		# Check if updated
		if( $this->db->affected_rows() )
		{
			return TRUE;
		}

		return FALSE;
	}

	// ---------------------------------------------------------------------

	/**
	 * removeFavouriteAct 	- Remove favorite activity
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @param varchar 	| $song_id 	| play song id
	 * @return boolean
	 */
	public function removeFavouriteAct($user_id, $song_id)
	{
		$this->db
			 ->where(["user_id" => $user_id, "activity_type" => "favourite"])
			 ->like("activity", $song_id)
			 ->delete(self::ACT_TBL);

		return $this->db->affected_rows();
	}

	// ---------------------------------------------------------------------

	/**
	 * removeFollowAct 	- Remove follow activity
	 *
	 * @param varchar 	| $user_id 	| user unique id
	 * @param varchar 	| $follow_id 	| play follow id
	 * @return boolean
	 */
	public function removeFollowAct($user_id, $follow_id)
	{
		$this->db
			 ->where(["user_id" => $user_id, "activity_type" => "follow"])
			 ->like("activity", $follow_id)
			 ->delete(self::ACT_TBL);

		return $this->db->affected_rows();
	}
}

// ----------------------------------------------------------
// END API MODEL
// ----------------------------------------------------------
